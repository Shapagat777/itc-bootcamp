import Header from "./components/Header/Header";

function App (props) {
    return (
        <>
            <Header />
        </>
    )
}

export default App;